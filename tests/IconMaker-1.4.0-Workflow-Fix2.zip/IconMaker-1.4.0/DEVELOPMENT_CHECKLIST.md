# IconMaker 1.4.0 Development Checklist

This checklist distinguishes changes implemented and checked in the current source tree from checks that require a Windows-hosted packaged executable. A checked item means the described implementation/test was completed here; it does not imply that the Windows release has already been published.

## 1. Foundation and dependency handling

- [x] Remove the **Install / repair Pillow** button from the main GUI.
- [x] Remove the GUI runtime installer action and its installation-message event handler.
- [x] Give source-run failures a Python/Pillow-specific diagnostic and packaged-build failures a download-a-fresh-EXE diagnostic.
- [x] Keep PyInstaller one-file packaging and explicit Pillow collection.
- [x] Add a packaged `--self-test` path that imports Pillow and constructs the GUI.
- [ ] **Windows verification pending:** run GitHub Actions and confirm `dist/IconMaker.exe --self-test` passes on the Windows runner.
- [ ] **Clean-machine verification pending:** open the released EXE on a Windows PC without Python installed.

## 2. Conversion control and progress

- [x] Add a **Cancel conversion** control during active jobs.
- [x] Cancellation stops before the next file and allows the current file to finish safely.
- [x] Show the current filename, item number, and percentage progress.
- [x] Keep conversion and scanning work off the GUI thread.
- [x] Add regression tests for cancellation before a job and cancellation requested during the first file.

## 3. Results and error reporting

- [x] Report successful, skipped, failed, elapsed-time, and unprocessed/cancelled totals.
- [x] Preserve per-file diagnostic log entries and exception details.
- [x] Continue processing after a per-image error.
- [x] Add a completion dialog with **Open output folder** and **Open activity log** actions.
- [x] Exercise successful, skipped, and failed conversion paths with automated tests.

## 4. Folder selection and batch management

- [x] Preserve folder mode and recursive subfolder conversion.
- [x] Add source scanning with supported-image counts before conversion.
- [x] Add a selected-image manager with add, remove, and clear actions.
- [x] Keep the main **Select images** action as a replace operation; use **Manage selection → Add images** to append files.
- [x] Smoke-test source scanning and the selected-image manager in a Tk virtual-display session.

## 5. Preview and image details

- [x] Preview the selected source image.
- [x] Show dimensions, format, transparency, and file size.
- [x] Handle unavailable previews with an explanation instead of crashing the application.
- [x] Automated conversion tests cover PNG, JPG, JPEG, WEBP, BMP, GIF, TIF, and TIFF input.

## 6. Themes and visual polish

- [x] Add **System**, **Light**, and **Dark** themes.
- [x] Persist the selected theme and update-check preference.
- [x] Apply theme colors to ttk controls, activity text, selection preview, and menus.
- [x] Redesign the main window with a branded header, source/destination card, side-by-side settings/overview panels, primary action bar, progress card, and restyled activity log.
- [x] Visually inspect the main window at the default 1060 × 780 layout and confirm the Activity Log has visible space.
- [x] Smoke-test switching through all three themes.
- [x] Create `assets/iconmaker.ico` with the supported Windows icon sizes and `assets/iconmaker.png` as its PNG source.
- [x] Configure the executable icon and package the ICO for the Tk window.
- [x] Embed the custom ICO and Windows file metadata directly during PyInstaller build (no post-build PE rewriting).
- [x] Include the PNG asset in the one-file bundle for the redesigned branded header and window icon.
- [ ] **Windows verification pending:** inspect the executable file icon and title-bar icon on Windows after the revised workflow run. PyInstaller now embeds the icon directly and no post-build resource editor touches the one-file executable.

## 7. About window and developer credit

- [x] Add an About window with application name and version.
- [x] Display **Made by The Pirate Dylan** in the main window and About window.
- [x] Include GitHub repository and bug-report links.
- [x] Smoke-test the About window in the GUI session.

## 8. GitHub update checker

- [x] Check the latest stable GitHub release in the background after startup by default.
- [x] Add a **Check for updates now…** menu command.
- [x] Add a setting to enable/disable startup checks.
- [x] Compare numeric version components so versions like `1.10.0` compare correctly against `1.9.0`.
- [x] Validate release URLs before offering to open them.
- [x] Handle unavailable GitHub/network responses without blocking startup.
- [x] Test the release-response parser with a mocked GitHub response.
- [ ] **Live-network verification pending:** confirm behavior against the public GitHub API after a stable `v1.4.0` release exists.

## 9. Preserve existing 1.3.0 functionality

- [x] Keep ICO size selection for 16, 24, 32, 48, 64, 128, and 256 pixels.
- [x] Keep all eight supported input extensions.
- [x] Keep all three fitting modes.
- [x] Keep original, `_icon`, and custom-prefix naming modes.
- [x] Keep default numbered suffix collision handling.
- [x] Keep recursive folder processing and relative subfolder output.
- [x] Keep settings-file compatibility while adding new defaults.
- [x] Keep atomic ICO output writing and per-file error handling.

## 10. Build, tests, and documentation

- [x] Update README and changelog for 1.4.0.
- [x] Update GitHub Actions to run syntax checks and automated regression tests before building.
- [x] Configure PyInstaller to embed the custom application icon and runtime ICO asset.
- [x] Configure PyInstaller to embed `assets/iconmaker.ico` and Windows file metadata in the PE resources during the build; remove post-build resource editing to preserve the one-file archive.
- [x] Add a regression guard that checks the workflow embeds both the custom ICO and the PNG window/header asset.
- [x] Bundle `assets/iconmaker.png` so the main window header and Tk window icon use the custom artwork.
- [x] Configure a Windows-runner smoke test that builds the EXE and constructs its GUI through `--self-test`.
- [x] Capture the GUI executable process exit code with `Start-Process -Wait -PassThru` and print the packaged crash log on failure.
- [x] Python syntax check: `python -m py_compile convert_icons.py` passed.
- [x] Automated regression suite: **14 tests passed** in the current development environment.
- [x] GUI smoke test passed in a Tk virtual-display session: app construction, theme switching, selected-image preview, About dialog, source scan, completion dialog, and settings persistence.
- [x] GitHub Actions YAML syntax parse and static workflow checks passed after workflow hardening.
- [x] Automated regression suite rerun after workflow changes: **14 tests passed**.
- [ ] **Final release gate pending:** run the GitHub Actions workflow and review its Windows EXE self-test result before publishing.

## Current release gate

The source, assets, documentation, unit tests, and local GUI smoke checks are complete in this package. The workflow now uses explicit PowerShell argument arrays, embeds the icon and version metadata during PyInstaller compilation, checks the embedded Windows icon resources, validates the executable size before running the self-test, and reports clearer step-specific failures. The previous 353,280-byte output was detected after the post-build resource-editing step; this version removes that step and measures the executable immediately after PyInstaller. The Windows-specific packaged build has **not** been run from this environment; do not describe the release as fully verified until the GitHub Actions Windows build and executable smoke test pass.
